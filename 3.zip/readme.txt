----------------[Terms of use]---------------------

You can:
✅-Use it on a server (in game download!) or in mod packs
✅-Use and edit it for YouTube videos and Content Creator edits (Linking back preferably but not needed)

You cannot:
❌-Redistribute edited or unedited assets as is
❌-Re-upload the pack

----------------[Credit]---------------------------


--Pack Creators:--

mr_ch0c0late (Creator and Idea)

Curse Forge: 		https://www.curseforge.com/members/mr_ch0c0late1
Planet Minecraft: 	https://www.planetminecraft.com/member/mr_ch0c0late1/
Twitter: 		https://twitter.com/mr_ch0c0late1



Zartrix 

Curse Forge:		https://www.curseforge.com/members/zartrix
Reddit: 		https://www.reddit.com/user/Zartrix